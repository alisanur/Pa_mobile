import 'package:flutter/material.dart';
import 'package:weather/models/constants.dart';
import 'package:weather/page/drawer.dart';
import 'package:weather/widget/WeatherDetails.dart'; // Import file WeatherDetail.dart

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String selectedCity = "Samarinda";
  final Constants constants = Constants(); // Instantiate Constants class

  final List<Map<String, dynamic>> forecastData = [
    {"day": "Sen", "temp": "16°C", "icon": Icons.cloud, "color": Colors.blue},
    {
      "day": "Sel",
      "temp": "18°C",
      "icon": Icons.wb_sunny,
      "color": Colors.orange
    },
    {
      "day": "Rab",
      "temp": "21°C",
      "icon": Icons.wb_cloudy,
      "color": Colors.grey
    },
    {
      "day": "Kam",
      "temp": "20°C",
      "icon": Icons.wb_sunny,
      "color": Colors.orange
    },
    {
      "day": "Jum",
      "temp": "19°C",
      "icon": Icons.wb_cloudy,
      "color": Colors.grey
    },
    {
      "day": "Sab",
      "temp": "22°C",
      "icon": Icons.wb_sunny,
      "color": Colors.orange
    },
    {"day": "Min", "temp": "23°C", "icon": Icons.cloud, "color": Colors.blue},
  ];

  void _showCitySelection() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Pilih Kota'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                _buildCityOption("Samarinda"),
                _buildCityOption("Berau"),
                _buildCityOption("Kutai Barat"),
                _buildCityOption("Kutai Kartanegara"),
                _buildCityOption("Kutai Timur"),
                _buildCityOption("Mahakam Ulu"),
                _buildCityOption("Paser"),
                _buildCityOption("Penajam Paser Utara"),
                _buildCityOption("Lambang"),
                _buildCityOption("Balikpapan"),
                _buildCityOption("Bontang"),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildCityOption(String city) {
    return ListTile(
      title: Text(city),
      onTap: () {
        setState(() {
          selectedCity = city;
        });
        Navigator.pop(context);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          children: [
            Text(
              selectedCity,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Text("Senin, 2 Mei"),
          ],
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.menu, color: Colors.black),
          onPressed: () {
            // Show the drawer
            showDialog(
              context: context,
              builder: (context) {
                return Stack(
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.of(context).pop();
                      },
                      child: Container(
                        color: Colors.black54,
                      ),
                    ),
                    Positioned(
                      left: 0,
                      top: 0,
                      bottom: 0,
                      width: MediaQuery.of(context).size.width * 0.7,
                      child: MyDrawer(),
                    ),
                  ],
                );
              },
            );
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.pin_drop),
            onPressed: _showCitySelection,
          ),
        ],
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(height: 20),

            // Bagian Cuaca Utama
            Container(
              width: 350,
              height: 250,
              margin: EdgeInsets.symmetric(horizontal: 16.0),
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: constants.primaryColor,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Stack(
                children: [
                  Positioned(
                    top: 0,
                    left: 0,
                    child: Image.asset(
                      'assets/pin.png',
                      width: 30,
                      height: 30,
                      color: constants.TertiaryColor,
                    ),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Center(
                        child: Image.asset(
                          'assets/showers.png',
                          width: 100,
                        ),
                      ),
                      Text(
                        "16°",
                        style: TextStyle(
                          fontSize: 60,
                          color: constants.TertiaryColor,
                        ),
                      ),
                      Text(
                        "Hujan Ringan",
                        style: TextStyle(fontSize: 20),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            SizedBox(height: 20),

            // Bagian Detail Cuaca
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                // Container untuk Kecepatan Angin
                Container(
                  padding: EdgeInsets.all(8.0),
                  decoration: BoxDecoration(
                    color: constants.primaryColor,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    children: [
                      Center(
                        child: Image.asset(
                          'assets/windspeed.png',
                          width: 40,
                        ),
                      ),
                      SizedBox(height: 5),
                      Text("6km/h",
                          style: TextStyle(color: constants.TertiaryColor)),
                      SizedBox(height: 5),
                      Text("wind Speed",
                          style: TextStyle(color: constants.TertiaryColor)),
                    ],
                  ),
                ),

                // Container untuk Kelembaban
                Container(
                  padding: EdgeInsets.all(8.0),
                  decoration: BoxDecoration(
                    color: constants.primaryColor,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    children: [
                      Center(
                        child: Image.asset(
                          'assets/max-temp.png',
                          width: 40,
                        ),
                      ),
                      SizedBox(height: 5),
                      Text("58%",
                          style: TextStyle(color: constants.TertiaryColor)),
                      SizedBox(height: 5),
                      Text("Kelembaban",
                          style: TextStyle(color: constants.TertiaryColor)),
                    ],
                  ),
                ),

                // Container untuk Suhu Maks
                Container(
                  padding: EdgeInsets.all(8.0),
                  decoration: BoxDecoration(
                    color: constants.primaryColor,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    children: [
                      Center(
                        child: Image.asset(
                          'assets/clear.png',
                          width: 40,
                        ),
                      ),
                      SizedBox(height: 5),
                      Text("16°C",
                          style: TextStyle(color: constants.TertiaryColor)),
                      SizedBox(height: 5),
                      Text("Suhu Maks",
                          style: TextStyle(color: constants.TertiaryColor)),
                    ],
                  ),
                ),
              ],
            ),

            SizedBox(height: 20),

            // Bagian Prakiraan Cuaca 7 Hari dengan Scroll Vertikal
            Expanded(
              child: Container(
                padding: EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: constants.secondaryColor,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "To Day",
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          "7 Next Day",
                          style: TextStyle(color: constants.TertiaryColor),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),

                    // ListView Scroll Vertikal untuk prakiraan 7 hari
                    Expanded(
                      child: ListView.builder(
                        itemCount: forecastData.length,
                        itemBuilder: (context, index) {
                          final data = forecastData[index];
                          return GestureDetector(
                            onTap: () {
                              // Navigasi ke halaman detail cuaca berdasarkan hari
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => WeatherDetail(
                                    cityName: selectedCity,
                                    day: data["day"],
                                  ),
                                ),
                              );
                            },
                            child: Container(
                              margin: EdgeInsets.symmetric(vertical: 8.0),
                              padding: EdgeInsets.all(16.0),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.2),
                                    spreadRadius: 2,
                                    blurRadius: 5,
                                  ),
                                ],
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    data["day"],
                                    style: TextStyle(fontSize: 18),
                                  ),
                                  Text(
                                    data["temp"],
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: data["color"],
                                    ),
                                  ),
                                  Icon(data["icon"], color: data["color"]),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
