import 'package:flutter/material.dart';
import 'package:weather/models/constants.dart';

class MyDrawer extends StatelessWidget {
  final Constants constants = Constants();

  ListTile listTile(
      BuildContext context, String text, IconData? icon, VoidCallback onTap) {
    return icon == null
        ? ListTile(
            onTap: onTap,
            title: Text(
              text,
              style: TextStyle(
                color: constants.TertiaryColor,
                fontSize: 14,
              ),
            ),
          )
        : ListTile(
            onTap: onTap,
            leading: Icon(
              icon,
              color: constants.primaryColor,
            ),
            title: Text(
              text,
              style: TextStyle(
                color: constants.TertiaryColor,
                fontSize: 14,
              ),
            ),
          );
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        physics: BouncingScrollPhysics(),
        padding: EdgeInsets.zero,
        children: [
          Builder(builder: (context) {
            return DrawerHeader(
              decoration: BoxDecoration(
                color: constants.primaryColor,
                border: Border.all(
                  color: constants.secondaryColor,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                    ),
                    child: Center(
                      child: Text(
                        "WU", // Replace with user's initials if available
                        style: TextStyle(
                            color: constants.secondaryColor,
                            fontSize: 20,
                            fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                  Text(
                    "Weather User",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                    ),
                  )
                ],
              ),
            );
          }),
          Column(
            children: [
              listTile(
                context,
                "Weather Forecast",
                Icons.cloud_outlined,
                () {
                  // Navigate to Weather
                },
              ),
              listTile(
                context,
                "Saved Locations",
                Icons.location_city_outlined,
                () {
                  // Navigate to weather
                },
              ),
              listTile(
                context,
                "Temperature Units",
                Icons.thermostat_outlined,
                () {
                  // Navigate to weather
                },
              ),
              listTile(
                context,
                "Settings",
                Icons.settings,
                () {
                  // Navigate to general settings
                },
              ),
              listTile(
                context,
                "Help Center",
                Icons.help_center_outlined,
                () {
                  // Navigate to help
                },
              ),
              Divider(),
              listTile(context, "Terms & Conditions / Privacy", null, () {}),
              ListTile(
                title: Text('Logout'),
                leading: Icon(Icons.logout),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}
